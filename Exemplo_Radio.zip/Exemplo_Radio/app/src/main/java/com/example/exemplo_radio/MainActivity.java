package com.example.exemplo_radio;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.RadioButton;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {


    private RadioButton radioButtonAndroid, radioButtonMicrosoft, radioButtonApple;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        radioButtonApple = findViewById(R.id.radio_apple);
        radioButtonAndroid = findViewById(R.id.radio_android);
        radioButtonMicrosoft = findViewById(R.id.radio_microsoft);
    } //onCreate

    public void onRadioButtonClicked(View view ){
        boolean checked = ((RadioButton)view).isChecked();
        if(view.getId() == R.id.radio_android){
            if(checked){
                Toast.makeText(this, "Acertou", Toast.LENGTH_SHORT).show();
            }
        }

        if(view.getId() == R.id.radio_microsoft){
            if(checked){
                Toast.makeText(this, "Errou", Toast.LENGTH_SHORT).show();
            }
        }

        if(view.getId() == R.id.radio_apple){
            if(checked){
                Toast.makeText(this, "Errou", Toast.LENGTH_SHORT).show();
            }
        }

    }
}