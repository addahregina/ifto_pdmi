package br.edu.ifto;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class ActivityCafe extends AppCompatActivity {

    private EditText editTextQuantidadeCafe;
    private Button buttonCafe;
    private double valores;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cafe);
        buttonCafe = findViewById(R.id.buttonCafe);
        editTextQuantidadeCafe = findViewById(R.id.editTextQuantidadeCafe);
        buttonCafe.setOnClickListener({new View.OnClickListener() {
            @Override
            public void onClick(View view){
                calcular();
            }
        });
    }

    }

    private void calcular(){
        int unidade = Integer.parseInt(editTextQuantidadeCafe.getText().toString());
        double total = unidade*2.50;
        Intent intent = new Intent(ActivityCafe.this, MainActivity.class);
        valores = valores +total;
        intent.putExtra("total",valores);
        startActivity(intent);
    }