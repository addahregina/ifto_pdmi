package br.edu.ifto;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class ActivityBolo extends AppCompatActivity {

    private EditText editTextQuantidadeBolo;
    private Button buttonBolo;
    private double valores;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bolo);
        buttonBolo = findViewById(R.id.buttonBolo);
        editTextQuantidadeBolo = findViewById(R.id.editTextQuantidadeBolo);
        buttonBolo.setOnClickListener({new View.OnClickListener() {
            @Override
            public void onClick(View view){
                calcular();
            }
        });
    }

    }

    private void calcular(){
        int unidade = Integer.parseInt(editTextQuantidadeBolo.getText().toString());
        double total = unidade*2.50;
        Intent intent = new Intent(ActivityBolo.this, MainActivity.class);
        valores = valores +total;
        intent.putExtra("total",valores);
        startActivity(intent);
    }