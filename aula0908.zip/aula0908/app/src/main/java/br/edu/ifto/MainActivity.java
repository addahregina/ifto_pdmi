package br.edu.ifto;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {


    private ImageView imageViewBolo;
    private ImageView imageViewCafe;
    private Button buttonCalcular;
    private TextView textViewResultado;

    private Double valores;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        imageViewBolo = findViewById(R.id.imageViewBolo);
        imageViewCafe = findViewById(R.id.imageViewCafe);
        buttonCalcular = findViewById(R.id.buttonCalcular);
        textViewResultado = findViewById(R.id.textViewResultado);

        Intent intent = getIntent();
        if(intent != null){
            double valor = intent.getDoubleExtra("total", 0);
            valores = valores+valor;
        }

    }

    public void calcular(){
        int unidade = Integer.parseInt(editTextQuantidadeCafe.getText().toString());
        double total = unidade*2.50;
        Intent intent = new Intent(ActivityCafe.this, MainActivity.class);
        valores = valores + total;
        intent.putExtra("total", valores);
        startActivity(intent);
    }

    public void escolher(View view){
        if (R.id.imageViewBolo == view.getId()){
            Intent intentBolo = new Intent(MainActivity.this, ActivityBolo.class);
            startActivity(intentBolo);
        }
        if(R.id.imageViewCafe == view.getId()){
            Intent intentCafe = new Intent(MainActivity.this, ActivityCafe.class);
            if(valores !=0){
                intentCafe.putExtra("valores");
            }
            startActivity(intentCafe);
        }
        if(R.id.buttonCalcular == view.getId()){
            textViewResultado.setText(String.valueOf());
        }
    }

}