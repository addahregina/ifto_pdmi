package br.edu.ifto.spinnerprogress;


import androidx.appcompat.app.AppCompatActivity;


import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity
        implements AdapterView.OnItemSelectedListener {
    private EditText editTextNome;
    private RadioButton radioButtonR, radioButtonI;
    private Button button;
    private Spinner spinner;
    private ArrayAdapter<String> adapter;
    private String idades[]={"20","30","40","50","..."};
    private Estudante e;
    private int i;
    private ProgressBar progressBar;
    private TextView textViewResultado;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editTextNome = findViewById(R.id.editTextNome);
        radioButtonI = findViewById(R.id.radioButtonI);
        radioButtonR = findViewById(R.id.radioButtonR);
        button = findViewById(R.id.button);
        spinner = findViewById(R.id.spinner);
        progressBar = findViewById(R.id.progressBar);
        textViewResultado = findViewById(R.id.textViewResultado);
        adapter = new ArrayAdapter<>(MainActivity.this,
                android.R.layout.simple_list_item_1,idades);
        adapter.setDropDownViewResource(android.R.layout
                .simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(this);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                executarProgressBar();
            }
        });


    }//onCreate


    private void executarProgressBar(){
        progressBar.setVisibility(View.VISIBLE);
        Handler handler =
                new Handler(Looper.getMainLooper());
        i = progressBar.getProgress();


        new Thread(new Runnable() {
            @Override
            public void run() {
                while(i<100){
                    i=i+10;
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            progressBar.setProgress(i);
                            if(i>=100){
                                textViewResultado.setText(e.toString());
                            }//if
                        }//run
                    });
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException ex) {
                        System.out.println(ex.getMessage());
                    }
                }//while
            }//run
        }).start();
    }//


    private String obterSituacao(){
        String s = "";
        if(radioButtonR.isChecked()){
            s = "regular";
        }
        if(radioButtonI.isChecked()){
            s="irregular";
        }
        return s;
    }//


    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
        int item = Integer.parseInt(idades[i]);
        e =new Estudante(editTextNome.getText().toString(),
                obterSituacao(),item);
    }


    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {
    }
}//class