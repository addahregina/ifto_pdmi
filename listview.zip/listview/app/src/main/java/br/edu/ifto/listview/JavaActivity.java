package br.edu.ifto.listview;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.widget.Toast;

public class JavaActivity extends AppCompatActivity {

    private RadioButton radioButtonGuido, radioButtonDennis, radioButtonJamesGoslig;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_java);

        radioButtonDennis = findViewById(R.id.radioButtonDennis);
        radioButtonGuido = findViewById(R.id.radioButtonGuido);
        radioButtonJamesGoslig = findViewById(R.id.radioButtonJamesGoslig);


    }
    public void onRadioCliked(View view) {
        boolean status = ((RadioButton)view).isChecked();
        if((view.getId() == R.id.radioButtonJamesGoslig)&&(status)){
            Toast.makeText(this, "Acertou!",
                    Toast.LENGTH_SHORT).show();
        }//if
        if((view.getId() == R.id.radioButtonGuido)&&(status)){
            Toast.makeText(this, "Errou!", Toast.LENGTH_SHORT).show();
            radioButtonGuido.setVisibility(RadioButton.INVISIBLE);
        }//if
        if((view.getId() == R.id.radioButtonDennis)&&(status)){
            Toast.makeText(this, "Errou!", Toast.LENGTH_SHORT).show();
            radioButtonDennis.setVisibility(RadioButton.INVISIBLE);
        }//if
    }
}