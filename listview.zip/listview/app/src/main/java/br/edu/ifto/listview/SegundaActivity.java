package br.edu.ifto.listview;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.RadioButton;
import android.widget.Toast;

public class SegundaActivity extends AppCompatActivity {
    
    private RadioButton radioButtonGuido, radioButtonDennis, radioButtonNiklaus;
    

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_segunda);
        
        radioButtonDennis = findViewById(R.id.radioButtonDennis);
        radioButtonGuido = findViewById(R.id.radioButtonGuido);
        radioButtonNiklaus = findViewById(R.id.radioButtonNiklaus);


    }
    public void onRadioCliked(View view) {
        boolean status = ((RadioButton)view).isChecked();
        if((view.getId() == R.id.radioButtonDennis)&&(status)){
            Toast.makeText(this, "Acertou",
                    Toast.LENGTH_SHORT).show();
        }//if
        if((view.getId() == R.id.radioButtonGuido)&&(status)){
            Toast.makeText(this, "Errouuu!!!", Toast.LENGTH_SHORT).show();
            radioButtonGuido.setVisibility(RadioButton.INVISIBLE);
        }//if
        if((view.getId() == R.id.radioButtonNiklaus)&&(status)){
            Toast.makeText(this, "Errouuu!!!", Toast.LENGTH_SHORT).show();
            radioButtonNiklaus.setVisibility(RadioButton.INVISIBLE);
        }//if
    }
}
