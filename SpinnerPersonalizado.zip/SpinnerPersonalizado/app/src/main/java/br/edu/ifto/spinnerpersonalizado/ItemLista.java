package br.edu.ifto.spinnerpersonalizado;

public class ItemLista {
    private int imagem;
    private String info;


    public ItemLista(int imagem, String info) {
        this.imagem = imagem;
        this.info = info;
    }


    public ItemLista() {
    }


    public int getImagem() {
        return imagem;
    }


    public void setImagem(int imagem) {
        this.imagem = imagem;
    }


    public String getInfo() {
        return info;
    }


    public void setInfo(String info) {
        this.info = info;
    }


    @Override
    public String toString() {
        return "ItemLista{" +
                "imagem=" + imagem +
                ", info='" + info + '\'' +
                '}';
    }
}

