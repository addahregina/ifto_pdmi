package br.edu.ifto.spinnerpersonalizado;

import androidx.appcompat.app.AppCompatActivity;


import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;


import java.util.ArrayList;


public class MainActivity extends AppCompatActivity
        implements AdapterView.OnItemSelectedListener {
    private Spinner spinner;
    private MyAdapter myAdapter;
    // private ArrayAdapter adapterPlanets;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        spinner = findViewById(R.id.spinner);


      /* adapterPlanets = ArrayAdapter.createFromResource(MainActivity.this,
               R.array.planets_array, android.R.layout.simple_spinner_item);
       adapterPlanets.setDropDownViewResource(android.R.
       layout.simple_spinner_dropdown_item);*/


        myAdapter = new MyAdapter(MainActivity.this,criarLista());
        spinner.setAdapter(myAdapter);
        spinner.setOnItemSelectedListener(this);
    }//onCreate


    private ArrayList<ItemLista> criarLista() {
        ArrayList<ItemLista> itens = new ArrayList<>();
        String[] planetas = getResources()
                .getStringArray(R.array.planets_array);
        ItemLista item1 =
                new ItemLista(R.drawable.mercurio,planetas[0]);
        ItemLista item2 =
                new ItemLista(R.drawable.venus,planetas[1]);
        ItemLista item3 =
                new ItemLista(R.drawable.terra,planetas[2]);
        ItemLista item4 =
                new ItemLista(R.drawable.marte,planetas[3]);
        ItemLista item5 =
                new ItemLista(R.drawable.jupter,planetas[4]);
        ItemLista item6 =
                new ItemLista(R.drawable.saturno,planetas[5]);
        ItemLista item7 =
                new ItemLista(R.drawable.urano,planetas[6]);
        ItemLista item8 =
                new ItemLista(R.drawable.netuno,planetas[7]);
        ItemLista item9 =
                new ItemLista(R.drawable.netuno,planetas[8]);


        itens.add(item1);
        itens.add(item2);
        itens.add(item3);
        itens.add(item4);
        itens.add(item5);
        itens.add(item6);
        itens.add(item7);
        itens.add(item8);
        itens.add(item9);

        return itens;


    }//


    @Override
    public void onItemSelected(AdapterView<?> adapterView,
                               View view, int i, long l) {
        ItemLista item = (ItemLista) spinner.getItemAtPosition(i);
        Toast.makeText(this, item.getInfo(),
                Toast.LENGTH_SHORT).show();


    }


    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {


    }
}//class