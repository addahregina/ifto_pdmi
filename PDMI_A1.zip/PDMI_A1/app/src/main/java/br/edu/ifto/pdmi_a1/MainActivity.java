package br.edu.ifto.pdmi_a1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;


/*2. Na segunda tela, peça para o usuário digitar o seu nome, dia, mês e ano de nascimento. Coloque um
botão cujo rótulo está definido como Brincando com as cores. Use o LinearLayout sentido vertical. */

public class MainActivity extends AppCompatActivity {

    private EditText editText_nome;
    private EditText editText_dia;
    private EditText editText_mes;
    private EditText editText_ano;
    private Button button_iniciar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editText_nome = findViewById(R.id.editText_nome);
        editText_dia = findViewById(R.id.editText_dia);
        editText_mes = findViewById(R.id.editText_mes);
        editText_ano = findViewById(R.id.editText_ano);
        button_iniciar = findViewById(R.id.button_iniciar);

        button_iniciar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // para qd for necessário
                String nome = editText_nome.getText().toString();
                //int dia = editText_dia.getText().toString();
                //int mes = editText_mes.getText().toString();
                //int ano = editText_ano.getText().toString();



                Intent it = new Intent(MainActivity.this, ColorsActivity.class);
                startActivity(it);

            }
        });

    }
}