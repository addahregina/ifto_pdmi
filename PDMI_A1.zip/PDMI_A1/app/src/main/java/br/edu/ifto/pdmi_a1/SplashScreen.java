package br.edu.ifto.pdmi_a1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;


/*1. Crie uma tela de apresentação antes de iniciar a interação do usuário com o aplicativo.
Use uma imagem relacionada com o tema. (valor: 0,5) */

public class SplashScreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);

        Log.i("Thread", Thread.currentThread().getName());
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent it = new Intent(SplashScreen.this, MainActivity.class);
                startActivity(it);
            }
        }, 1000);

        Log.i("Thread", Thread.currentThread().getName());
    }
}