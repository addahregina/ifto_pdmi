package br.edu.ifto.pdmi_a1;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.SparseIntArray;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.concurrent.ThreadLocalRandom;


/*Ao clicar na opção brincando com as cores, deve ser aberta outra tela cuja cor do background
deve ser trocada de tempo em tempo. Devem ser mostradas 10 cores. As 10 cores devem ser
sorteadas aleatoriamente de uma lista geral contendo 20 cores. Crie uma estrutura de dados
que armazene as 20 cores e valores. Cada cor deve ter um valor correlacionado (valor: 2,0)
 */
public class ColorsActivity extends AppCompatActivity {

    private String colorName;
    private TextView textView_colors_nome;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_colors);

        LinearLayout layout=(LinearLayout)findViewById(R.id.colorsLayout);




        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {


                ArrayList<Integer> colors = new ArrayList<Integer>();
                colors.add(R.color.purple_200);
                colors.add(R.color.purple_500);
                colors.add(R.color.purple_700);


                int randon = ThreadLocalRandom.current().nextInt(1, 5 + 1);

                layout.setBackgroundColor(colors.get(randon));
            }
        }, 1000);






        //v.setBackgroundResource(R.color.purple_200);*/
    }
}