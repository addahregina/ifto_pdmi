package br.edu.ifto.splash;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private EditText editTextNumero;
    private Button buttonJogar;
    private int numero;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextNumero = findViewById(R.id.edtiTextNumero);
        buttonJogar = findViewById(R.id.buttonJogar);

        buttonJogar.setOnClickListener(new View.OnClickListener(){
           @Override
           public void onClick(View view){
               numero = Integer.parseInt(editTextNumero.getText().toString());
               gerarNumero(numero);
           }
        });
    }

    private void gerarNumero(int numJogador) {
        Random r = new Random();
        int numComputador = r.nextInt(11);
        if(numComputador>numJogador){
            Toast.makeText(this, "Android venceu: "+numComputador+">"+numJogador, Toast.LENGTH_SHORT).show();
        } else if(numComputador < numJogador){
            Toast.makeText(this, "Jogador ganhou: "+numJogador+" > "+numComputador, Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Empate: "+numComputador+" + "+numJogador, Toast.LENGTH_SHORT).show();
        }
    }
}