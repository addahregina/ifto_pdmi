package br.edu.ifto.listapersonalizada;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ClipData;
import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private ListView listView;
    private MeuAdapter adapter;
    private ArrayList<ItemLista> itens;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = findViewById(R.id.listView);
        criarLista();
    }

    private void criarLista() {
        itens = new ArrayList<>();
        ItemLista item1 = new ItemLista("Mochila", R.drawable.bag1);
        ItemLista item2 = new ItemLista("Bolsa", R.drawable.bag2);
        ItemLista item3 = new ItemLista("Mochila", R.drawable.bag1);
        ItemLista item4 = new ItemLista("Bolsa", R.drawable.bag2);

        itens.add(item1);
        itens.add(item2);
        itens.add(item3);
        itens.add(item4);

        adapter = new MeuAdapter(this, itens);
        listView.setAdapter(adapter);
    }
}