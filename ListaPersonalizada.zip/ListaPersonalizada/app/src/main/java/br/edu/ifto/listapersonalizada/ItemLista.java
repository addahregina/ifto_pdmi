package br.edu.ifto.listapersonalizada;

public class ItemLista {
    private String info;
    private int imagem;

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public int getImagem() {
        return imagem;
    }

    public void setImagem(int imagem) {
        this.imagem = imagem;
    }

    public ItemLista(){

    }

    public ItemLista(String info, int imagem){
        this.info = info;
        this.imagem = imagem;
    }

}
