package br.edu.ifto;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private EditText editText_num1;
    private EditText editText_num2;
    private EditText editText_operador;
    private Button button_calcular;
    private TextView textView_resultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editText_num1 = findViewById(R.id.editTextNum1);
        editText_num2 = findViewById(R.id.editTextNum2);
        editText_operador = findViewById(R.id.editTextOperador);
        button_calcular = findViewById(R.id.button_calcular);

        button_calcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               Integer num1 = Integer.parseInt(editText_num1.getText().toString());
               Integer num2 = Integer.parseInt(editText_num2.getText().toString());

                String operador = editText_operador.getText().toString();
                Integer resultado = 0;


                switch (operador){
                    case "+":
                        resultado = num1+num2;
                        break;
                    case "-":
                        resultado = num1-num2;
                        break;
                    case "*":
                        resultado = num1*num2;
                        break;
                    case "/":
                        resultado = num1/num2;
                        break;
                    default:
                        resultado = 0;
                        break;
                }

                Intent it = new Intent(MainActivity.this, ResultadoActivity.class);
                it.putExtra("dados", resultado);
                startActivity(it);
            }
        });
    }
}