package br.edu.ifto.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class PinguimActivity extends AppCompatActivity {

    private Button button_proximo;
    private Button button_anterior;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pinguim);

        button_proximo = findViewById(R.id.buttonProximo);
        button_anterior = findViewById(R.id.buttonAnterior);

        button_anterior.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                Intent it = new Intent(PinguimActivity.this, MainActivity.class);
                startActivity(it);
            }
        });

        button_proximo.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                Intent it = new Intent(PinguimActivity.this, PerguntasActivity.class);
                startActivity(it);
            }
        });
    }
}