package br.edu.ifto.imc;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    private EditText editText_nome;
    private EditText editText_peso;
    private EditText editText_altura;
    private Button button_calcular;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editText_nome = findViewById(R.id.editText_nome);
        editText_peso = findViewById(R.id.editText_peso);
        editText_altura = findViewById(R.id.editText_altura);
        button_calcular = findViewById(R.id.button_calcular_imc);

        button_calcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nome = editText_nome.getText().toString();
                double peso = Double.parseDouble(editText_peso.getText().toString().replace("," , "."));
                double altura = Double.parseDouble(editText_peso.getText().toString().replace("," , "."));
                double imc = peso / (altura * altura);
                String resultado;


                if(imc < 18.5){
                    resultado = "Abaixo do normal";
                } else if((imc >= 18.6) && (imc <= 24.9)){
                    resultado = "Normal";
                } else if((imc >= 25.0) && (imc <= 29.9)){
                    resultado = "Sobrepeso";
                } else if(( imc >= 30.0) && (imc <= 34.9)){
                    resultado = "Obesidade grau I";
                } else if((imc >= 35.0) && (imc <= 39.9)){
                    resultado = "Obesidade grau II";
                } else {
                    resultado = "Obesidade grau III";
                }
                /*Ref.: https://abeso.org.br/obesidade-e-sindrome-metabolica/calculadora-imc/
                O link disponível na atividade estava retornando erro de timeout */


                String IMC = Double.toString(imc);

                Intent it = new Intent(MainActivity.this, ImcActivity.class);
                it.putExtra("textView_imc_nome", "Olá, "+nome+"!");
                it.putExtra("textView_imc_indice", IMC);
                it.putExtra("textView_imc_classificacao", resultado);
                startActivity(it);
            }
        });
    }
}