package br.edu.ifto.imc;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import java.text.BreakIterator;

public class ImcActivity extends AppCompatActivity {

    private TextView textView_imc_nome;
    private TextView textView_imc_indice;
    private TextView textView_imc_classificacao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_imc);

        textView_imc_nome = findViewById(R.id.textView_imc_nome);
        textView_imc_indice = findViewById(R.id.textView_imc_indice);
        textView_imc_classificacao = findViewById(R.id.textView_imc_classificacao);
        
        Intent i = getIntent();

        String nome = i.getStringExtra("textView_imc_nome");
        String indice = i.getStringExtra("textView_imc_indice");
        String classificacao = i.getStringExtra("textView_imc_classificacao");

        textView_imc_nome.setText(nome);
        textView_imc_indice.setText(indice);
        textView_imc_classificacao.setText(classificacao);
    }
}